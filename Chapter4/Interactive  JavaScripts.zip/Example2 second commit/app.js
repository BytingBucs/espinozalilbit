

var main = function () {
	"use strict";

	console.log("hello world");
};

$(document).ready(main);