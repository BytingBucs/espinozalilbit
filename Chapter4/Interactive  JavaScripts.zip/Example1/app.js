
var main = function() {
	"use stric";

	window.alert("hello World");
};
$(document).ready(main);